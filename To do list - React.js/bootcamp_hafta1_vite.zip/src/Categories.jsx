import React, { useState } from "react";

const Categories = (props) => {
  const [input, setInput] = useState("");
  return (
    <div style={{ border: "1px solid red", width: 500, height: 500 }}>
      Categories
      <input value={input} onChange={(e) => setInput(e.target.value)} />
      <button
        onClick={() => {
          props.onCategoryAddClick(input);
        }}
      >
        Add
      </button>
      <ul>
        {props.categories.map((item, idx) => (
          <li>
            <button onClick={() => props.onCategoryEditClick(idx)}>
              {item.name}
            </button>
            <button onClick={() => props.onCategoryDelClick(idx)}>Del</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Categories;
