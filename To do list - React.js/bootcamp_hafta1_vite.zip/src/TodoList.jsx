import React from "react";

const TodoList = () => {
  return (
    <div style={{ border: "1px solid red", width: 500, height: 500 }}>
      TodoList
    </div>
  );
};

export default TodoList;
