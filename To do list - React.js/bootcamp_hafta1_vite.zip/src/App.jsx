import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import TodoList from "./TodoList";
import Categories from "./Categories";
import StatusList from "./StatusList";

const ModalEnum = {
  TodoList: 1,
  Categories: 2,
  StatusList: 3,
};

function App() {
  const [currentModal, setCurrentModal] = useState(ModalEnum.TodoList);
  const [currentCategory, setCurrentCategory] = useState(0);
  const [appData, setAppData] = useState({
    todoList: [],
    categories: [
      { name: "kişisel", statusList: ["new", "todo", "in progress", "done"] },
      {
        name: "grapecity",
        statusList: [
          "new",
          "todo",
          "in progress",
          "waiting for deployment",
          "waiting for qa",
          "in qa",
          "done",
        ],
      },
      {
        name: "bootcamp",
        statusList: [
          "new",
          "preparing",
          "on classroom",
          "homework given",
          "homework control",
          "done",
        ],
      },
    ],
  });
  const handleModalChange = (index) => setCurrentModal(index);
  const handleCategoryChange = (index) => {
    setCurrentCategory(index);
    setCurrentModal(ModalEnum.StatusList);
  };
  const handleAddNewCategory = (name) => {
    setAppData({
      ...appData,
      categories: [
        ...appData.categories,
        {
          name: name,
          statusList: [],
        },
      ],
    });
  };
  const handleDeleteCategoryByIndex = (idx) => {
    const isCancel = !confirm(
      `Are you sure about to delete category "${appData.categories[idx].name}" ? `
    );
    if (isCancel) return;

    setAppData({
      ...appData,
      categories: appData.categories.filter((item, _idx) => idx !== _idx),
    });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", flexDirection: "row" }}>
        <button onClick={() => handleModalChange(ModalEnum.TodoList)}>
          TodoList
        </button>
        <button onClick={() => handleModalChange(ModalEnum.Categories)}>
          Categories
        </button>
      </div>
      <div>
        {currentModal === ModalEnum.TodoList && <TodoList />}
        {currentModal === ModalEnum.Categories && (
          <Categories
            categories={appData.categories}
            onCategoryEditClick={handleCategoryChange}
            onCategoryAddClick={handleAddNewCategory}
            onCategoryDelClick={handleDeleteCategoryByIndex}
          />
        )}
        {currentModal === ModalEnum.StatusList && (
          <StatusList
            categoryIndex={currentCategory}
            categoryName={appData.categories[currentCategory].name}
          />
        )}
      </div>
    </div>
  );
}

export default App;
