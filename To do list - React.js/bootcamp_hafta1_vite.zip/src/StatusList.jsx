import React from "react";

const StatusList = (props) => {
  return (
    <div style={{ border: "1px solid red", width: 500, height: 500 }}>
      StatusList of {props.categoryName}
      <ul>
        <li>Status1</li>
        <li>Status2</li>
        <li>Status3</li>
        <li>Status4</li>
        <li>Status5</li>
      </ul>
    </div>
  );
};

export default StatusList;
