import { useState } from "../geact.js";
import Form from "./Form.js";
import Menu from "./Menu.js";
import { createElementFromTemplate } from "../geact.js";

const App = () => {
  const [arr1, setArr] = useState([
    "Anasayfa",
    "Siparişlerim",
    "Sepetim",
    "Alışveriş Geçmişim",
    "Logout",
  ]);

  const handleAddNewMenuItem = (sender) => {
    const text = sender.parentElement.getElementsByTagName("input")[0].value;
    setArr([...arr1, text]);
  };

  const template = `<div id="app">
      ${Menu(arr1).outerHTML}
      ${
        Form({
          onAddNewMenuItem: handleAddNewMenuItem,
        }).outerHTML
      }
    
    <div>`;

  return createElementFromTemplate(template);
};
export default App;
