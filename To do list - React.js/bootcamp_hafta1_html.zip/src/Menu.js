import { createElementFromTemplate } from "../geact.js";
import Item from "./Item.js";

const Menu = (arr) => {
  const template = /*html*/ `
      <div id="menu-container">
          <ul>
              ${arr.map((item) => `<li>${Item(item).outerHTML}</li>`).join("")}
          </ul>
      </div>
      `;
  return createElementFromTemplate(template);
};

export default Menu;
