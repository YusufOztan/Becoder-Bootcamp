import { createElementFromTemplate } from "../geact.js";

const Item = (text) => {
  const template = /*html*/ `<a href="http://www.google.com">${text}</a>`;
  return createElementFromTemplate(template);
};
export default Item;
