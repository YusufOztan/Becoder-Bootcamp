import { createElementFromTemplate } from "../geact.js";

const Form = (props) => {
  window.onAddNewMenuItem = props.onAddNewMenuItem;
  const template = /*html*/ `
      <form>
        <input name="new-menu-item" id="new-menu-item" />
        <button type="button" onclick="onAddNewMenuItem(this)">Kaydet</button>
      </form>
      `;
  return createElementFromTemplate(template);
};

export default Form