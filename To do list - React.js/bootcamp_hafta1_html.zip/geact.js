import { updateDom } from "./main.js";

let stateCount = 0;
export const useState = (initialValue) => {
  if (!window.UseState) window.UseState = [];
  if (window.UseState[stateCount] === undefined) {
    window.UseState[stateCount] = initialValue;
  }
  const value = window.UseState[0];
  const setter = (param) => {
    window.UseState[stateCount] = param;
    updateDom();
  };
  stateCount = stateCount + 1;
  return [value, setter];
};

export const geact = (node, app) => {
  node.innerHTML = app().outerHTML;
  stateCount = 0;
};

export const createElementFromTemplate = (template) => {
  const host = document.createElement("div");
  host.innerHTML = template;
  return host.firstElementChild;
};
