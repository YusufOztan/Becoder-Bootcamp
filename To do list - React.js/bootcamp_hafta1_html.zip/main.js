import { geact } from "./geact.js";
import App from "./src/App.js";
const root = document.getElementById("root");
export const updateDom = () => geact(root, App);
geact(root, App);
