import React from "react";
import { useState } from "react";
const Form = (props) => {
  const [text, setText] = useState("başka");


  return (
      <form>
        <input name="new-menu-item" id="new-menu-item" />
        <button type="button" onClick={props.onAddNewMenuItem} children="Hakan"/>
      </form>
  );
};

export default Form;
