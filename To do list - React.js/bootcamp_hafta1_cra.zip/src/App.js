import { useState } from "react";
import Form from "./Form";
import Menu from "./Menu";
function App() {
  const [arr1, setArr] = useState([
    "Anasayfa",
    "Siparişlerim",
    "Sepetim",
    "Alışveriş Geçmişim",
    "Logout",
  ]);
  const handleAddNewMenuItem = (e) => {
    const input = e.target.parentElement.getElementsByTagName("input")[0];
    const text = input.value;
    setArr([...arr1, text]);
    input.value = "";
  };
  return (
    <div id="app">
      <Menu source={arr1} />
      <Form onAddNewMenuItem={handleAddNewMenuItem} />
    </div>
  );
}

export default App;
