import React from "react";
import Item from "./Item";
const Menu = (props) => {
  return (
    <div id="menu-container">
      <ul>
        {props.source.map((item) => (
          <li>
            <Item text={item} />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Menu;
