import React from "react";

const Item = ({ text }) => {
  return <a href="http://www.google.com">{text}</a>;
};

export default Item;
